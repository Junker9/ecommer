# 🛍️ MODA Store – E-commerce Demo

Este es un proyecto básico de tienda en línea con diseño moderno y minimalista, desarrollado como demo para propuestas freelance. El objetivo es mostrar funcionalidades esenciales de una tienda de ropa, incluyendo variaciones de producto y reseñas.

## 🎯 Características principales

- 🧥 Producto con variaciones: selección de talla y color
- ⭐ Sección de reseñas de clientes simuladas
- 📱 Diseño responsivo: se adapta a móviles, tabletas y escritorio
- 🎨 Interfaz limpia y moderna con tipografía Poppins
- 💻 Desarrollado con HTML, CSS y JavaScript puro (sin frameworks pesados)

## 📁 Estructura del proyecto

```
ecommerce-demo/
├── index.html        → Página principal del demo
├── styles.css        → Estilos personalizados
└── README.md         → Descripción del proyecto
```

## 🚀 Cómo probarlo

1. Descarga el repositorio:
   ```bash
   git clone https://github.com/tu-usuario/ecommerce-demo.git
   ```
2. Abre el archivo `index.html` en tu navegador.

## 📌 Notas

- Este demo es una base inicial y puede expandirse fácilmente con carrito de compras, backend y pasarela de pagos.
- Pensado como muestra para plataformas freelance como Freelancer, Workana, etc.

## 👨‍💻 Autor

**Leo**  
Freelance Web Developer  
🌐 [https://github.com/tu-usuario](https://github.com/tu-usuario)
